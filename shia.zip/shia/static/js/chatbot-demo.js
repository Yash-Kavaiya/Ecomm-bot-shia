// static/js/chatbot-demo.js

document.addEventListener('DOMContentLoaded', function() {
    // Handle demo prompt card clicks
    const demoPromptCards = document.querySelectorAll('.demo-prompt-card');
    
    demoPromptCards.forEach(card => {
      card.addEventListener('click', function() {
        const prompt = this.getAttribute('data-prompt');
        
        if (prompt) {
          // Get Dialogflow Messenger element
          const dfMessenger = document.querySelector('df-messenger');
          
          if (dfMessenger) {
            // Create and dispatch events to open the chatbot and send a message
            const openEvent = new CustomEvent('df-messenger-open');
            dfMessenger.dispatchEvent(openEvent);
            
            // Short delay to ensure the chatbot is open before sending the message
            setTimeout(() => {
              // Create and dispatch event to send the message
              const sendEvent = new CustomEvent('df-user-input-entered', {
                detail: {
                  input: prompt
                }
              });
              dfMessenger.dispatchEvent(sendEvent);
            }, 500);
            
            // Update the UI to indicate which prompt was selected
            demoPromptCards.forEach(p => p.classList.remove('active'));
            this.classList.add('active');
          }
        }
      });
    });
    
    // Helper tooltip display/hide logic
    const demoHelper = document.querySelector('.demo-helper');
    
    if (demoHelper) {
      // Show helper for 5 seconds, then fade out
      setTimeout(() => {
        demoHelper.style.opacity = '0';
        setTimeout(() => {
          demoHelper.style.display = 'none';
        }, 500);
      }, 5000);
    }
    
    // Handle Dialogflow Messenger events
    const dfMessenger = document.querySelector('df-messenger');
    
    if (dfMessenger) {
      // Listen for response events to enhance UI feedback
      dfMessenger.addEventListener('df-response-received', event => {
        console.log('Bot response:', event.detail);
        
        // Optional: You could add visual feedback based on responses
        // For example, highlighting features related to the current conversation
      });
      
      // Listen for chatbot open/close events
      dfMessenger.addEventListener('df-messenger-opened', () => {
        console.log('Chatbot opened');
        
        // Optional: Adjust UI when chatbot is opened
        const demoContainer = document.querySelector('.demo-container');
        if (demoContainer) {
          demoContainer.classList.add('chatbot-active');
        }
      });
      
      dfMessenger.addEventListener('df-messenger-closed', () => {
        console.log('Chatbot closed');
        
        // Optional: Reset UI when chatbot is closed
        const demoContainer = document.querySelector('.demo-container');
        if (demoContainer) {
          demoContainer.classList.remove('chatbot-active');
        }
      });
    }
    
    // Custom events for demonstration scenarios (if on demo page)
    const scenarioExamples = document.querySelectorAll('.demo-scenario-examples li');
    
    if (scenarioExamples.length > 0) {
      scenarioExamples.forEach(example => {
        example.addEventListener('click', function() {
          const prompt = this.textContent;
          
          if (prompt && dfMessenger) {
            // Open chatbot
            const openEvent = new CustomEvent('df-messenger-open');
            dfMessenger.dispatchEvent(openEvent);
            
            // Send message
            setTimeout(() => {
              const sendEvent = new CustomEvent('df-user-input-entered', {
                detail: {
                  input: prompt
                }
              });
              dfMessenger.dispatchEvent(sendEvent);
            }, 500);
          }
        });
      });
    }
  });