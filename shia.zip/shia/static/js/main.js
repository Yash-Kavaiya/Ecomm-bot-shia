// static/js/main.js

document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuBtn && navLinks) {
      mobileMenuBtn.addEventListener('click', function() {
        navLinks.classList.toggle('active');
        
        // Toggle menu icon
        const menuIcon = mobileMenuBtn.querySelector('.material-icons');
        if (menuIcon.textContent === 'menu') {
          menuIcon.textContent = 'close';
        } else {
          menuIcon.textContent = 'menu';
        }
      });
    }
    
    // Handle clicks outside the menu to close it
    document.addEventListener('click', function(event) {
      if (navLinks && navLinks.classList.contains('active') && 
          !navLinks.contains(event.target) && 
          !mobileMenuBtn.contains(event.target)) {
        navLinks.classList.remove('active');
        const menuIcon = mobileMenuBtn.querySelector('.material-icons');
        menuIcon.textContent = 'menu';
      }
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href').substring(1);
        const targetElement = document.getElementById(targetId);
        
        if (targetElement) {
          window.scrollTo({
            top: targetElement.offsetTop - 80,
            behavior: 'smooth'
          });
        }
      });
    });
    
    // "Try Shia Now" button click handlers
    const tryNowBtns = document.querySelectorAll('#try-now-btn, #cta-try-now-btn');
    
    tryNowBtns.forEach(btn => {
      if (btn) {
        btn.addEventListener('click', function() {
          // Trigger the Dialogflow Messenger to open
          const dfMessenger = document.querySelector('df-messenger');
          
          if (dfMessenger) {
            // Create and dispatch a custom event to open the chatbot
            const event = new CustomEvent('df-messenger-open');
            dfMessenger.dispatchEvent(event);
            
            // Scroll to make sure chatbot is visible
            window.scrollTo({
              top: document.body.scrollHeight,
              behavior: 'smooth'
            });
          }
        });
      }
    });
    
    // Header scroll effect
    const header = document.querySelector('header');
    
    if (header) {
      window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
          header.style.boxShadow = 'var(--shadow-md)';
          header.style.backgroundColor = 'rgba(255, 255, 255, 0.97)';
        } else {
          header.style.boxShadow = 'var(--shadow-sm)';
          header.style.backgroundColor = 'var(--white)';
        }
      });
    }
    
    // Feature card hover effects
    const featureCards = document.querySelectorAll('.feature-card');
    
    featureCards.forEach(card => {
      card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-10px)';
      });
      
      card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
      });
    });
    
    // Testimonial carousel (if more than 3 testimonials)
    const testimonialSlider = document.querySelector('.testimonials-slider');
    const testimonialCards = document.querySelectorAll('.testimonial-card');
    
    if (testimonialSlider && testimonialCards.length > 3) {
      // Simple auto-scrolling carousel implementation
      let currentIndex = 0;
      const cardWidth = testimonialCards[0].offsetWidth;
      
      setInterval(() => {
        currentIndex = (currentIndex + 1) % testimonialCards.length;
        testimonialSlider.scrollTo({
          left: currentIndex * (cardWidth + 16),
          behavior: 'smooth'
        });
      }, 5000);
    }
  });