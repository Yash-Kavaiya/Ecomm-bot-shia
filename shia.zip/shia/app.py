# app.py - Main Flask application file

from flask import Flask, render_template, jsonify
import os

app = Flask(__name__)

# Mock data for demonstration
features = [
    {
        "id": 1,
        "title": "Natural Language Product Search",
        "description": "Find products using conversational queries just like you'd ask a store associate.",
        "icon": "search"
    },
    {
        "id": 2,
        "title": "Order Tracking & Management",
        "description": "Check order status, track shipments, and manage returns through simple conversation.",
        "icon": "local_shipping"
    },
    {
        "id": 3,
        "title": "Personalized Recommendations",
        "description": "Receive product suggestions tailored to your preferences and browsing history.",
        "icon": "thumb_up"
    },
    {
        "id": 4, 
        "title": "Customer Support & Issue Resolution",
        "description": "Get instant help with common issues and seamless escalation when needed.",
        "icon": "support_agent"
    },
    {
        "id": 5,
        "title": "Account Management",
        "description": "Update your profile, preferences, and payment methods through simple commands.",
        "icon": "person"
    },
    {
        "id": 6,
        "title": "Special Offers & Promotions",
        "description": "Discover personalized deals and exclusive promotions based on your interests.",
        "icon": "local_offer"
    }
]

metrics = [
    {"value": "85%", "label": "First-Contact Resolution"},
    {"value": "3.5x", "label": "Faster Issue Resolution"},
    {"value": "92%", "label": "User Satisfaction"},
    {"value": "40%", "label": "Reduction in Support Tickets"}
]

testimonials = [
    {
        "quote": "Shia helped me find exactly what I needed, even when I wasn't sure how to describe it. It's like shopping with a knowledgeable friend.",
        "author": "Sarah T., Customer"
    },
    {
        "quote": "The ability to check my order status anytime without waiting on hold has made online shopping so much more convenient.",
        "author": "Michael R., Customer"
    },
    {
        "quote": "Since implementing Shia, our customer service team can focus on complex issues while the chatbot handles routine inquiries.",
        "author": "Jennifer L., E-commerce Manager"
    }
]

# Routes
@app.route('/')
def index():
    return render_template('index.html', features=features, metrics=metrics, testimonials=testimonials)

@app.route('/api/features')
def get_features():
    return jsonify(features)

@app.route('/demo')
def demo():
    return render_template('demo.html')

@app.route('/architecture')
def architecture():
    return render_template('architecture.html')

@app.route('/documentation')
def documentation():
    return render_template('documentation.html')

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)